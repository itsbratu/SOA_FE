export type Shop = {
    id: string;
    name: string;
    location: string;
    income: number;
    openedAt: Date;
}