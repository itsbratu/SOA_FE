import { Module } from '@nestjs/common';
import { ScheduleModule } from '@nestjs/schedule';
import { ClientsModule, Transport } from '@nestjs/microservices';
import { ShopsController } from './shops.controller';
import { ShopService } from './shops.service';

@Module({
  imports: [
    ScheduleModule.forRoot(),
    ClientsModule.register([
      {
        name: 'AUTH_SERVICE',
        transport: Transport.TCP,
        options: {
          // Use Docker service name for Auth service
          host: 'auth_service',  // Replace with the container name of auth service
          port: 3002,  // Assuming this is the correct port
        },
      },
      {
        name: 'REDIS_UPDATER',
        transport: Transport.REDIS,
        options: {
          // Use Docker service name for Redis
          host: 'redis_instance_1',  // Replace with the container name of Redis
          port: 6379,  // Assuming this is the correct port
        },
      },
      {
        name: 'SHOP_LOGS_SERVICE',
        transport: Transport.RMQ,
        options: {
          // Use Docker service name for RabbitMQ
          urls: ['amqp://rabbitmq:5672'],  // Replace with the container name of RabbitMQ
          queue: 'shop_logs',
          queueOptions: {
            durable: false,
          },
        },
      },
    ]),
  ],
  controllers: [ShopsController],
  providers: [ShopService],
})
export class ShopsModule {}
